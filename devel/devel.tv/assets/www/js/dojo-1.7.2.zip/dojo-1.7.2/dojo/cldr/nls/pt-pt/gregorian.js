//>>built
define(
"dojo/cldr/nls/pt-pt/gregorian", //begin v1.x content
{
	"quarters-standAlone-wide": [
		"1.º trimestre",
		"2.º trimestre",
		"3.º trimestre",
		"4.º trimestre"
	],
	"quarters-format-abbr": [
		"1.º trimestre",
		"2.º trimestre",
		"3.º trimestre",
		"4.º trimestre"
	],
	"dayPeriods-standAlone-wide-am": "a.m.",
	"dateFormat-medium": "d 'de' MMM 'de' yyyy",
	"quarters-standAlone-abbr": [
		"1.º trimestre",
		"2.º trimestre",
		"3.º trimestre",
		"4.º trimestre"
	],
	"dateFormatItem-Hm": "HH:mm",
	"dayPeriods-standAlone-abbr-pm": "p.m.",
	"dateFormatItem-HHmmss": "HH:mm:ss",
	"dateFormatItem-hm": "h:mm a",
	"months-standAlone-wide": [
		"Janeiro",
		"Fevereiro",
		"Março",
		"Abril",
		"Maio",
		"Junho",
		"Julho",
		"Agosto",
		"Setembro",
		"Outubro",
		"Novembro",
		"Dezembro"
	],
	"dayPeriods-standAlone-abbr-am": "a.m.",
	"dayPeriods-format-wide-pm": "Depois do meio-dia",
	"months-standAlone-abbr": [
		"Jan",
		"Fev",
		"Mar",
		"Abr",
		"Mai",
		"Jun",
		"Jul",
		"Ago",
		"Set",
		"Out",
		"Nov",
		"Dez"
	],
	"dateFormatItem-yQQQ": "QQQ 'de' y",
	"dayPeriods-format-wide-am": "Antes do meio-dia",
	"dateFormatItem-Hms": "HH:mm:ss",
	"dayPeriods-format-abbr-pm": "p.m.",
	"dateFormatItem-yyQ": "QQQ 'de' yy",
	"dateFormatItem-ms": "mm:ss",
	"dayPeriods-format-abbr-am": "a.m.",
	"months-format-wide": [
		"Janeiro",
		"Fevereiro",
		"Março",
		"Abril",
		"Maio",
		"Junho",
		"Julho",
		"Agosto",
		"Setembro",
		"Outubro",
		"Novembro",
		"Dezembro"
	],
	"days-standAlone-wide": [
		"Domingo",
		"Segunda-feira",
		"Terça-feira",
		"Quarta-feira",
		"Quinta-feira",
		"Sexta-feira",
		"Sábado"
	],
	"dateFormatItem-HHmm": "HH:mm",
	"months-format-abbr": [
		"Jan",
		"Fev",
		"Mar",
		"Abr",
		"Mai",
		"Jun",
		"Jul",
		"Ago",
		"Set",
		"Out",
		"Nov",
		"Dez"
	],
	"days-standAlone-abbr": [
		"Domingo",
		"Segunda-feira",
		"Terça-feira",
		"Quarta-feira",
		"Quinta-feira",
		"Sexta-feira",
		"Sábado"
	],
	"days-format-wide": [
		"Domingo",
		"Segunda-feira",
		"Terça-feira",
		"Quarta-feira",
		"Quinta-feira",
		"Sexta-feira",
		"Sábado"
	],
	"dateFormatItem-hms": "h:mm:ss a",
	"dateFormatItem-yQ": "QQQ 'de' yyyy",
	"quarters-format-wide": [
		"1.º trimestre",
		"2.º trimestre",
		"3.º trimestre",
		"4.º trimestre"
	],
	"dayPeriods-standAlone-wide-pm": "p.m.",
	"days-format-abbr": [
		"Domingo",
		"Segunda-feira",
		"Terça-feira",
		"Quarta-feira",
		"Quinta-feira",
		"Sexta-feira",
		"Sábado"
	]
}
//end v1.x content
);