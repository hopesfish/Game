//>>built
define(
"dojo/cldr/nls/pt-pt/number", //begin v1.x content
{
	"currencyFormat": "#,##0.00 ¤",
	"group": " "
}
//end v1.x content
);